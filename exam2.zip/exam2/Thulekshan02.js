// A. write a function that returns a random number from 0 to 9 and stores is in the winning digits array//
let winningDight= ((1,4,0,3,1,8,9,4));
let playerDight =((6,2,5,3,4,8,1,7));

function calculateArray(winningDight){
    for (let i =0;i<Math.length;i++){
        for(let j;i<Math.length[i];j++){
        console.log(Math[i][j]=Math.floor()*random)
            
         return "random number from ";
        }
    }
}


//B. write a function that compares the winningDigits array and the playerDighit array ,then generate the output.//
function comparesArray (number){
    for( let i=0;i<Math.length;i++){
        for(let j=0;i<math[0].length;j++ ){
        
            console.log(math[i][j]=Math.floor()*random)
        }
            
         return "compares the winning Array and playerdigits";
    }

}



//C.  execute the above tasks within the main function//
console.log(calculateArray(winningDight))
console.log(comparesArray|(number))






//02 //
//A.The programme should have a return function to count the number of digits in  the number n.//

